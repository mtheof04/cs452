package main

import (
	"os"
	"strconv"
)

func GenerateHotels(f *os.File) {
	f.WriteString(
`[    
    {
        "id": "1",
        "name": "Clift Hotel",
        "phoneNumber": "(415) 775-4700",
        "description": "A 6-minute walk from Union Square and 4 minutes from a Muni Metro station, this luxury hotel designed by Philippe Starck features an artsy furniture collection in the lobby, including work by Salvador Dali.",
        "address": {
            "streetNumber": "495",
            "streetName": "Geary St",
            "city": "San Francisco",
            "state": "CA",
            "country": "United States",
            "postalCode": "94102",
            "lat": 37.7867,
            "lon": -122.4112
        }
    },
    {
        "id": "2",
        "name": "W San Francisco",
        "phoneNumber": "(415) 777-5300",
        "description": "Less than a block from the Yerba Buena Center for the Arts, this trendy hotel is a 12-minute walk from Union Square.",
        "address": {
            "streetNumber": "181",
            "streetName": "3rd St",
            "city": "San Francisco",
            "state": "CA",
            "country": "United States",
            "postalCode": "94103",
            "lat": 37.7854,
            "lon": -122.4005
        }
    },
    {
        "id": "3",
        "name": "Hotel Zetta",
        "phoneNumber": "(415) 543-8555",
        "description": "A 3-minute walk from the Powell Street cable-car turnaround and BART rail station, this hip hotel 9 minutes from Union Square combines high-tech lodging with artsy touches.",
        "address": {
            "streetNumber": "55",
            "streetName": "5th St",
            "city": "San Francisco",
            "state": "CA",
            "country": "United States",
            "postalCode": "94103",
            "lat": 37.7834,
            "lon": -122.4071
        }
    },
    {
        "id": "4",
        "name": "Hotel Vitale",
        "phoneNumber": "(415) 278-3700",
        "description": "This waterfront hotel with Bay Bridge views is 3 blocks from the Financial District and a 4-minute walk from the Ferry Building.",
        "address": {
            "streetNumber": "8",
            "streetName": "Mission St",
            "city": "San Francisco",
            "state": "CA",
            "country": "United States",
            "postalCode": "94105",
            "lat": 37.7936,
            "lon": -122.3930
    }
    },
    {
        "id": "5",
        "name": "Phoenix Hotel",
        "phoneNumber": "(415) 776-1380",
        "description": "Located in the Tenderloin neighborhood, a 10-minute walk from a BART rail station, this retro motor lodge has hosted many rock musicians and other celebrities since the 1950s. It’s a 4-minute walk from the historic Great American Music Hall nightclub.",
        "address": {
            "streetNumber": "601",
            "streetName": "Eddy St",
            "city": "San Francisco",
            "state": "CA",
            "country": "United States",
            "postalCode": "94109",
            "lat": 37.7831,
            "lon": -122.4181
        }
    },
    {
        "id": "6",
        "name": "St. Regis San Francisco",
        "phoneNumber": "(415) 284-4000",
        "description": "St. Regis Museum Tower is a 42-story, 484 ft skyscraper in the South of Market district of San Francisco, California, adjacent to Yerba Buena Gardens, Moscone Center, PacBell Building and the San Francisco Museum of Modern Art.",
        "address": {
            "streetNumber": "125",
            "streetName": "3rd St",
            "city": "San Francisco",
            "state": "CA",
            "country": "United States",
            "postalCode": "94109",
            "lat": 37.7863,
            "lon": -122.4015
        }
    }`)
		
	// add up to 80 hotels
	for i := 7; i <= 80; i++ {
		hotel_id := strconv.Itoa(i)
		phone_num := "(415) 284-40" + hotel_id
		lat := strconv.FormatFloat(37.7835 + float64(i)/500.0*3, 'f', 4, 64)
		lon := strconv.FormatFloat(-122.41 + float64(i)/500.0*4, 'f', 4, 64)

		f.WriteString(",")
		f.WriteString(
`    
    {
       "id": "` + hotel_id + `",
       "name": "St. Regis San Francisco",
       "phoneNumber": "` + phone_num + `",
       "description": "St. Regis Museum Tower is a 42-story, 484 ft skyscraper in the South of Market district of San Francisco, California, adjacent to Yerba Buena Gardens, Moscone Center, PacBell Building and the San Francisco Museum of Modern Art.",
       "address": {
           "streetNumber": "125",
           "streetName": "3rd St",
           "city": "San Francisco",
           "state": "CA",
           "country": "United States",
           "postalCode": "94109",
           "lat": ` + lat + `,
           "lon": ` + lon + `
       }
    }`)
	}
	f.WriteString("\n]\n")
}
